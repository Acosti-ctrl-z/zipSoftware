from django.contrib import admin
from Medicamentos.models import Medicamento
from Laboratorios.models import Laboratorios
from Farmacias.models import Farmacia

# Register your models here.
admin.site.register(Medicamento)
admin.site.register(Laboratorios)
admin.site.register(Farmacia)